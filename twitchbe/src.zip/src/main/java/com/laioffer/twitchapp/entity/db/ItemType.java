package com.laioffer.twitchapp.entity.db;


public enum ItemType {
    STREAM, VIDEO, CLIP
}
